from flask import Flask, render_template, flash, request
from flask.ext.wtf import Form
from wtforms import TextField, TextAreaField, PasswordField, SubmitField, SelectField, HiddenField
from wtforms.validators import DataRequired, ValidationError

SECRET_KEY = 'development'

app = Flask(__name__)
app.config.from_object(__name__)

class SimpleForm(Form):

    title = TextField("Title", validators=[DataRequired()])
    text = TextAreaField("Text", validators=[DataRequired()])
    language = SelectField('Programming Language', choices=[('cpp', 'C++'), ('py', 'Python'), ('text', 'Plain Text')])
    id = HiddenField('id111')
    submit = SubmitField("Share")


@app.route('/',methods=['post', 'get'])
def hello_world():
    form = SimpleForm()

    if request.method == 'POST':
        if not form.validate():
            flash('All fields are required.')
            return render_template('example.html', form=form)
        else:
            return 'Form posted.'

    elif request.method == 'GET':
        form.id = 11
        return render_template('example.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)